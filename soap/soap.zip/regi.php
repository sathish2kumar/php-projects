<?php
//somewhere set a value
$var = "a value";
?>

<script>
// then echo it into the js/html stream
// and assign to a js variable
spge = '<?php echo $var ;?>';

// then
alert(spge);

</script>
echo 'document.getElementById("id3").style.padding="285px 260px";';
  echo 'document.getElementById("id3").innerHTML ="date2 is profit="+s+"compare date1 AND date1 is loss="+s+"compare date2");</script>';